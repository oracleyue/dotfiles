pylint -f parseable -r n $1
exit 0
