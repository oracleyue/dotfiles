#ifndef __FUNC_H
#define __FUNC_H

void func();

#endif
/* func.h */
