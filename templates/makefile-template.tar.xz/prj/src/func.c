#include <stdio.h>

void func(){
    printf("hello, world!\n");
}
