#include <stdio.h>
#include "main.h"

int main()
{
    func();

    return 0;
}

